
import React from 'react';
import Header from '@/components/Header';
import CubeFaces from '@/components/CubeFaces';
import ScrambleAlgorithm from '@/components/ScrambleAlgorithm';
import ScrambledCubeVisualization from '@/components/ScrambledCubeVisualization';
import CreateRoom from '@/components/CreateRoom';
import { motion } from 'framer-motion';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 to-white">
      <Header />
      
      <main className="flex-1 py-8 px-4 sm:px-6 max-w-7xl mx-auto w-full">
        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Understand cube notation and movement patterns
          </h1>
          <p className="mt-3 text-xl text-gray-600 max-w-3xl mx-auto">
            Practice, compete, and improve your speed cubing with our interactive tools
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <ScrambleAlgorithm />
          <CubeFaces />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <ScrambledCubeVisualization />
          </div>
          <CreateRoom />
        </div>
      </main>
      
      <footer className="py-4 text-center text-gray-600 text-sm">
        © {new Date().getFullYear()} CubeSpeed. All rights reserved.
      </footer>
    </div>
  );
};

export default Index;
