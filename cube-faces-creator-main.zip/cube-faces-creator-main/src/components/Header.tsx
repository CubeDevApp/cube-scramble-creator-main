
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import SignInModal from './SignInModal';

const Header = () => {
  const [showSignInModal, setShowSignInModal] = useState(false);
  
  return (
    <header className="w-full py-4 px-6 flex justify-between items-center animate-fade-in">
      <div className="flex items-center gap-2">
        <div className="w-12 h-12 bg-blue-600 rounded-md shadow-md flex items-center justify-center transform rotate-12 transition-transform hover:rotate-45 duration-300">
          <span className="text-white font-bold">↺</span>
        </div>
        <h1 className="text-2xl font-bold text-blue-600">CubeSpeed</h1>
      </div>
      
      <div className="flex items-center gap-4">
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => setShowSignInModal(true)}
        >
          Sign In
        </Button>
      </div>
      
      <SignInModal 
        isOpen={showSignInModal}
        onClose={() => setShowSignInModal(false)}
      />
    </header>
  );
};

export default Header;
