
import React from 'react';
import { motion } from 'framer-motion';

type CubeMove = {
  notation: string;
  color: string;
  textColor?: string;
};

const ScrambleAlgorithm: React.FC = () => {
  const moves: CubeMove[] = [
    { notation: 'B2', color: 'bg-cubeBlue', textColor: 'text-white' },
    { notation: 'U2', color: 'bg-white', textColor: 'text-gray-800' },
    { notation: 'R', color: 'bg-cubeRed', textColor: 'text-white' },
    { notation: 'D', color: 'bg-cubeYellow', textColor: 'text-gray-800' },
    { notation: 'F', color: 'bg-cubeGreen', textColor: 'text-white' },
    { notation: "U'", color: 'bg-white', textColor: 'text-gray-800' },
    { notation: "L'", color: 'bg-cubeOrange', textColor: 'text-white' },
    
    { notation: "B'", color: 'bg-cubeBlue', textColor: 'text-white' },
    { notation: 'D2', color: 'bg-cubeYellow', textColor: 'text-gray-800' },
    { notation: 'F', color: 'bg-cubeGreen', textColor: 'text-white' },
    { notation: 'U2', color: 'bg-white', textColor: 'text-gray-800' },
    { notation: 'R2', color: 'bg-cubeRed', textColor: 'text-white' },
    { notation: 'D', color: 'bg-cubeYellow', textColor: 'text-gray-800' },
    { notation: 'B', color: 'bg-cubeBlue', textColor: 'text-white' },
    
    { notation: 'L', color: 'bg-cubeOrange', textColor: 'text-white' },
    { notation: 'F', color: 'bg-cubeGreen', textColor: 'text-white' },
    { notation: "D'", color: 'bg-cubeYellow', textColor: 'text-gray-800' },
    { notation: 'L', color: 'bg-cubeOrange', textColor: 'text-white' },
    { notation: "B'", color: 'bg-cubeBlue', textColor: 'text-white' },
    { notation: 'U', color: 'bg-white', textColor: 'text-gray-800' },
  ];

  return (
    <div className="glass-card p-6 animate-fade-up" style={{ animationDelay: '0.1s' }}>
      <h2 className="text-2xl font-bold mb-6 text-center">Scramble Algorithm</h2>
      
      <div className="flex flex-wrap justify-center gap-2">
        {moves.map((move, index) => (
          <motion.div
            key={index}
            className={`w-10 h-10 rounded-md flex items-center justify-center font-bold text-xl shadow-sm ${move.color} ${move.textColor || 'text-white'}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            {move.notation}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ScrambleAlgorithm;
