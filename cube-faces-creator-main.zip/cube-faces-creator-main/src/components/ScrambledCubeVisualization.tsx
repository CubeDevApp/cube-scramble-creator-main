
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

type CubeColor = 'bg-white' | 'bg-yellow-400' | 'bg-green-500' | 'bg-blue-600' | 'bg-red-600' | 'bg-orange-500';

const ScrambledCubeVisualization: React.FC = () => {
  const [loaded, setLoaded] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoaded(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Define the cube state visualization
  const upFace: CubeColor[][] = [
    ['bg-white', 'bg-white', 'bg-white'],
    ['bg-white', 'bg-white', 'bg-blue-600'],
    ['bg-white', 'bg-orange-500', 'bg-green-500']
  ];
  
  const frontFace: CubeColor[][] = [
    ['bg-green-500', 'bg-yellow-400', 'bg-green-500'],
    ['bg-white', 'bg-green-500', 'bg-red-600'],
    ['bg-green-500', 'bg-white', 'bg-green-500']
  ];
  
  const rightFace: CubeColor[][] = [
    ['bg-red-600', 'bg-green-500', 'bg-red-600'],
    ['bg-red-600', 'bg-red-600', 'bg-orange-500'],
    ['bg-yellow-400', 'bg-red-600', 'bg-blue-600']
  ];
  
  const leftFace: CubeColor[][] = [
    ['bg-orange-500', 'bg-red-600', 'bg-yellow-400'],
    ['bg-green-500', 'bg-orange-500', 'bg-orange-500'],
    ['bg-orange-500', 'bg-white', 'bg-blue-600']
  ];
  
  const backFace: CubeColor[][] = [
    ['bg-blue-600', 'bg-blue-600', 'bg-white'],
    ['bg-blue-600', 'bg-blue-600', 'bg-blue-600'],
    ['bg-yellow-400', 'bg-red-600', 'bg-blue-600']
  ];
  
  const downFace: CubeColor[][] = [
    ['bg-red-600', 'bg-green-500', 'bg-yellow-400'],
    ['bg-yellow-400', 'bg-yellow-400', 'bg-yellow-400'],
    ['bg-red-600', 'bg-yellow-400', 'bg-white']
  ];

  // Function to render a single cube face
  const renderFace = (face: CubeColor[][], label: string, color: string, delay: number) => (
    <div className="flex flex-col items-center mb-6 transform transition-all duration-500" style={{ opacity: loaded ? 1 : 0, transform: loaded ? 'translateY(0)' : 'translateY(20px)' }}>
      <div className="grid grid-cols-3 gap-1 mb-1">
        {face.map((row, rowIndex) => (
          <React.Fragment key={rowIndex}>
            {row.map((cellColor, cellIndex) => (
              <motion.div
                key={`${rowIndex}-${cellIndex}`}
                className={`cube-mini-cell ${cellColor}`}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: loaded ? 1 : 0, scale: loaded ? 1 : 0.8 }}
                transition={{ duration: 0.2, delay: delay + (rowIndex * 3 + cellIndex) * 0.02 }}
              />
            ))}
          </React.Fragment>
        ))}
      </div>
      <span className={`text-sm font-medium mt-1 ${color}`}>{label}</span>
    </div>
  );

  return (
    <div className="glass-card p-6 w-full animate-fade-up" style={{ animationDelay: '0.3s' }}>
      <h2 className="text-2xl font-bold mb-6 text-center">Scrambled Cube Visualization</h2>
      
      {/* Up face */}
      <div className="flex justify-center mb-4">
        {renderFace(upFace, 'Up (White)', 'text-gray-500', 0.1)}
      </div>
      
      {/* Middle faces (Left, Front, Right, Back) */}
      <div className="flex justify-center gap-4 mb-4">
        {renderFace(leftFace, 'Left (Orange)', 'text-orange-500', 0.2)}
        {renderFace(frontFace, 'Front (Green)', 'text-green-500', 0.3)}
        {renderFace(rightFace, 'Right (Red)', 'text-red-600', 0.4)}
        {renderFace(backFace, 'Back (Blue)', 'text-blue-600', 0.5)}
      </div>
      
      {/* Down face */}
      <div className="flex justify-center">
        {renderFace(downFace, 'Down (Yellow)', 'text-yellow-400', 0.6)}
      </div>
    </div>
  );
};

export default ScrambledCubeVisualization;
