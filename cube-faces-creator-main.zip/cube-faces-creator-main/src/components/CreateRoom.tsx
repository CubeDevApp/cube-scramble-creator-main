
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Users, Clock, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const CreateRoom: React.FC = () => {
  const [roomName, setRoomName] = useState('');
  const [maxPlayers, setMaxPlayers] = useState(10);
  const [timeLimit, setTimeLimit] = useState(5);
  const { toast } = useToast();
  
  const handleCreateRoom = () => {
    if (!roomName.trim()) {
      toast({
        title: "Room name is required",
        description: "Please enter a name for your room",
        variant: "destructive"
      });
      return;
    }
    
    // Logic to create room
    console.log('Creating room:', { roomName, maxPlayers, timeLimit });
    toast({
      title: "Room Created!",
      description: `Your room "${roomName}" has been created.`,
    });
    
    // Reset form
    setRoomName('');
  };
  
  return (
    <motion.div 
      className="glass-card p-6 animate-fade-up"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      style={{ animationDelay: '0.4s' }}
    >
      <Tabs defaultValue="create" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="create">Create Room</TabsTrigger>
          <TabsTrigger value="join">Join Room</TabsTrigger>
        </TabsList>
        
        <TabsContent value="create" className="space-y-4">
          <h2 className="text-2xl font-bold mb-6 text-center">Create Room</h2>
          
          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="room-name">Room Name</Label>
              <Input 
                id="room-name" 
                placeholder="Enter a name for your room" 
                value={roomName}
                onChange={(e) => setRoomName(e.target.value)}
                className="focus:ring-cubeBlue focus:border-cubeBlue transition-all duration-300"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-1">
                  <Users size={16} className="text-gray-500" />
                  <Label htmlFor="max-players">Max Players</Label>
                </div>
                <div className="flex rounded-md border overflow-hidden">
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setMaxPlayers(Math.max(2, maxPlayers - 1))}
                    className="rounded-none w-12 flex-grow-0"
                  >
                    -
                  </Button>
                  <div className="flex-1 flex items-center justify-center">
                    {maxPlayers}
                  </div>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setMaxPlayers(Math.min(10, maxPlayers + 1))}
                    className="rounded-none w-12 flex-grow-0"
                  >
                    +
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-1">
                  <Clock size={16} className="text-gray-500" />
                  <Label htmlFor="time-limit">Time Limit (min)</Label>
                </div>
                <div className="flex rounded-md border overflow-hidden">
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setTimeLimit(Math.max(1, timeLimit - 1))}
                    className="rounded-none w-12 flex-grow-0"
                  >
                    -
                  </Button>
                  <div className="flex-1 flex items-center justify-center">
                    {timeLimit}
                  </div>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setTimeLimit(Math.min(30, timeLimit + 1))}
                    className="rounded-none w-12 flex-grow-0"
                  >
                    +
                  </Button>
                </div>
              </div>
            </div>
            
            <Button 
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700 transition-all duration-300 group"
              onClick={handleCreateRoom}
            >
              <span>Create Room</span>
              <ChevronRight size={16} className="ml-2 transition-transform group-hover:translate-x-1 duration-300" />
            </Button>
          </div>
        </TabsContent>
        
        <TabsContent value="join" className="space-y-4">
          <h2 className="text-2xl font-bold mb-6 text-center">Join Room</h2>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="room-code">Room Code</Label>
              <Input 
                id="room-code" 
                placeholder="Enter room code" 
                className="focus:ring-cubeBlue focus:border-cubeBlue transition-all duration-300"
              />
            </div>
            
            <Button 
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700 transition-all duration-300 group"
            >
              <span>Join Room</span>
              <ChevronRight size={16} className="ml-2 transition-transform group-hover:translate-x-1 duration-300" />
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default CreateRoom;
