
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const CubeFaces: React.FC = () => {
  const [loaded, setLoaded] = useState(false);
  
  useEffect(() => {
    setLoaded(true);
  }, []);

  return (
    <div className="glass-card p-6 animate-fade-up" style={{ animationDelay: '0.2s' }}>
      <h2 className="text-2xl font-bold mb-6 text-center">Cube Faces</h2>
      
      <div className="flex flex-col items-center gap-6">
        {/* Top row - White (Up) face - Single square */}
        <motion.div 
          className="w-20 h-20 rounded-lg bg-white border border-gray-200 shadow-sm"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: loaded ? 1 : 0, scale: loaded ? 1 : 0.8 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        />
        
        {/* Middle row - Orange, Green, Red, Blue faces */}
        <div className="flex justify-center gap-4">
          <motion.div 
            className="w-20 h-20 rounded-lg bg-orange-500"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: loaded ? 1 : 0, scale: loaded ? 1 : 0.8 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          />
          <motion.div 
            className="w-20 h-20 rounded-lg bg-green-500"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: loaded ? 1 : 0, scale: loaded ? 1 : 0.8 }}
            transition={{ duration: 0.3, delay: 0.3 }}
          />
          <motion.div 
            className="w-20 h-20 rounded-lg bg-red-600"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: loaded ? 1 : 0, scale: loaded ? 1 : 0.8 }}
            transition={{ duration: 0.3, delay: 0.4 }}
          />
          <motion.div 
            className="w-20 h-20 rounded-lg bg-blue-600"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: loaded ? 1 : 0, scale: loaded ? 1 : 0.8 }}
            transition={{ duration: 0.3, delay: 0.5 }}
          />
        </div>
        
        {/* Bottom row - Yellow (Down) face */}
        <motion.div 
          className="w-20 h-20 rounded-lg bg-yellow-400"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: loaded ? 1 : 0, scale: loaded ? 1 : 0.8 }}
          transition={{ duration: 0.3, delay: 0.6 }}
        />
      </div>
    </div>
  );
};

export default CubeFaces;
